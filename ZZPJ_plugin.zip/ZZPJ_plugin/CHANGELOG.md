<!-- Keep a Changelog guide -> https://keepachangelog.com -->

# ZZPJ_plugin Changelog

## [Unreleased]
### Added
- Initial scaffold created from [IntelliJ Platform Plugin Template](https://github.com/JetBrains/intellij-platform-plugin-template)
